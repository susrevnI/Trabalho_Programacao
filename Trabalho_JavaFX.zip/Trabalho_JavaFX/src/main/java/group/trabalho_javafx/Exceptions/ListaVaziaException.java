package group.trabalho_javafx.Exceptions;

public class ListaVaziaException extends Exception {
    
    public ListaVaziaException(){
        super();
    }
}
