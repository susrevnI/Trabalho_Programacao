package group.trabalho_javafx.Exceptions;

public class SenhaAcceptedException extends Exception {

    public SenhaAcceptedException() {
        super("Senha Correta.");
    }
    
}