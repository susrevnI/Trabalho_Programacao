package group.trabalho_javafx.Exceptions;

public class AtributoException extends Exception {
    
    public AtributoException(String atributos){
        super(atributos);
    }
}
