package group.trabalho_javafx.Exceptions;

public class SenhaErroException extends Exception {

    public SenhaErroException() {
        super("Senha Incorreta.");
    }
    
}