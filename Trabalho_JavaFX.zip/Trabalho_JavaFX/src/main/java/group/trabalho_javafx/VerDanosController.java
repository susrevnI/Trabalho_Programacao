package group.trabalho_javafx;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;

import group.trabalho_javafx.Util.Listas;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class VerDanosController implements Initializable {

    @FXML
    private TableColumn<Dano, String> colunaDescricaoDanos;

    @FXML
    private TableView<Dano> tabelaDanos;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colunaDescricaoDanos.setCellValueFactory( new PropertyValueFactory<>("descricaoDano"));
        //ObservableList<String> obsListaDanos = FXCollections.observableList(resourceBundle.getString(null));
        //tabelaDanos.setItems();

        ObservableList<Dano> obsListaDanos = FXCollections.observableList(Listas.listaDanos);
        System.out.println(Listas.listaDanos);
        System.out.println(obsListaDanos);
        tabelaDanos.setItems(obsListaDanos);
    }

}
